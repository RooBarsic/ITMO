package common;

import javax.swing.*;

public class MessageFrame {
    public MessageFrame(String message){
        JOptionPane.showMessageDialog(null, message);
    }
}

