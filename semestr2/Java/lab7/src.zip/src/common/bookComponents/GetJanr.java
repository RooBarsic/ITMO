package common.bookComponents;

public interface GetJanr {
    public Janrs getJanr();
}