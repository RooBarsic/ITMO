package common.bookComponents;

public interface GetName {
    public String getName();
}
