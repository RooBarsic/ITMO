package сlient;

import сlient.client.frames.ClientMainFrame;

public class ClientDataLog {
    public static ClientMainFrame clientFrame;
    public static String host;
    public static int port;
}
